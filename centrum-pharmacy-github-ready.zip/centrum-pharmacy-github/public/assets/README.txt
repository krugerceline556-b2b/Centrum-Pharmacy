Place your website images in this folder.

The code expects these exact filenames:

ChatGPT Image May 28, 2026, 04_24_26 PM.png
ChatGPT Image May 28, 2026, 04_28_13 PM.png
IMG_1403.jpg
IMG_1409.jpg
IMG_1415.jpg
IMG_1425-2.jpg
IMG_1426.jpg
IMG_1436-2.jpg
IMG_1448.jpg
IMG_2303(1).jpg
download.jpeg
image(5).png
