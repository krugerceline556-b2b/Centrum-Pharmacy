# Centrum Pharmacy Website

This is a GitHub-ready Vite + React + Tailwind website.

## Local setup

1. Install Node.js.
2. Open this folder in VS Code.
3. Run:

```bash
npm install
npm run dev
```

## Images

Place all website images inside `public/assets/` using the exact filenames listed in `public/assets/README.txt`.

## Upload to GitHub

Create a new GitHub repository, then upload this entire folder.

## Build

```bash
npm run build
```

The production-ready files will be created in the `dist/` folder.
